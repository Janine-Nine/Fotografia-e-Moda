# Fotografia da Moda

Site profissional de fotografia de moda desenvolvido com React, Vite, TailwindCSS e animações modernas.

## 🚀 Tecnologias

- React 18
- Vite
- TailwindCSS
- Framer Motion para animações
- React Router Dom para navegação
- PropTypes para validação de props
- Componentes otimizados e reutilizáveis

## 📦 Instalação

1. Clone o repositório:
   ```bash
   git clone [seu-repositorio]
   ```

2. Entre na pasta do projeto:
   ```bash
   cd fotografia-da-moda
   ```

3. Instale as dependências:
   ```bash
   npm install
   ```

4. Rode o servidor de desenvolvimento:
   ```bash
   npm run dev
   ```

5. Abra no navegador: http://localhost:5173

## 📂 Estrutura do Projeto

```
fotografia-da-moda/
├── src/
│   ├── assets/         # Imagens e outros recursos
│   ├── components/     # Componentes reutilizáveis
│   ├── pages/         # Páginas da aplicação
│   └── styles/        # Arquivos CSS
├── backup_html/       # Backup dos arquivos HTML originais
└── public/           # Arquivos públicos
```

## 🎨 Componentes

- `Button`: Botão reutilizável com variantes
- `Card`: Componente de card para serviços e portfólio
- `OptimizedImage`: Componente de imagem com lazy loading
- `AnimatedElement`: Wrapper para animações de entrada

## 📱 Responsividade

O site é totalmente responsivo, adaptando-se a diferentes tamanhos de tela:
- Desktop (1024px+)
- Tablet (768px - 1023px)
- Mobile (até 767px)

## 🔒 Backup

Os arquivos HTML originais estão preservados na pasta `backup_html/` para referência.

## 📝 Licença

Este projeto está sob a licença MIT. Veja o arquivo [LICENSE](LICENSE) para mais detalhes.

## 🤝 Contribuindo

1. Fork o projeto
2. Crie sua branch de feature (`git checkout -b feature/AmazingFeature`)
3. Commit suas mudanças (`git commit -m 'Add some AmazingFeature'`)
4. Push para a branch (`git push origin feature/AmazingFeature`)
5. Abra um Pull Request
