function Sobre() {
  return (
    <section className="p-8 text-center bg-pink-100 min-h-screen">
      <h2 className="text-3xl font-bold text-pink-600 mb-4">Sobre Nós</h2>
      <p className="max-w-3xl mx-auto text-gray-700">
        Somos apaixonados por capturar o melhor da moda através da fotografia. 
        Nosso estúdio trabalha com ensaios editoriais, catálogos e campanhas que valorizam a beleza e a autenticidade de cada modelo.
      </p>
    </section>
  );
}
// ...existing code...
