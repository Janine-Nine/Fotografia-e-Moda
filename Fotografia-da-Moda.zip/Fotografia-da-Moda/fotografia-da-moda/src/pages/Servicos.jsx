function Servicos() {
  return (
    <section className="p-8 bg-pink-100 min-h-screen">
      <h2 className="text-3xl font-bold text-center text-pink-600 mb-6">Serviços</h2>
      <div className="grid md:grid-cols-3 gap-8 text-center">
        <div className="p-6 bg-white rounded-lg shadow hover:shadow-xl">
          <h3 className="font-semibold mb-2">Ensaios Fotográficos</h3>
          <p>Book de moda, retratos e campanhas publicitárias.</p>
        </div>
        <div className="p-6 bg-white rounded-lg shadow hover:shadow-xl">
          <h3 className="font-semibold mb-2">Eventos de Moda</h3>
          <p>Desfiles, bastidores e coberturas exclusivas.</p>
        </div>
        <div className="p-6 bg-white rounded-lg shadow hover:shadow-xl">
          <h3 className="font-semibold mb-2">Lookbook & Catálogos</h3>
          <p>Produção de imagens para marcas e coleções.</p>
        </div>
      </div>
    </section>
  );
}
// ...existing code...
