
import { useEffect, useState } from 'react';

function Portfolio() {
  const [images, setImages] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simular carregamento de imagens do portfolio
    // Em produção, isso viria de uma API ou CMS
    const portfolioImages = [
      {
        id: 1,
        src: '/src/assets/images/portfolio/look1.jpg',
        alt: 'Look 1',
        category: 'Editorial'
      },
      {
        id: 2,
        src: '/src/assets/images/portfolio/look2.jpg',
        alt: 'Look 2',
        category: 'Campanha'
      },
      {
        id: 3,
        src: '/src/assets/images/portfolio/look3.jpg',
        alt: 'Look 3',
        category: 'Editorial'
      }
    ];

    // Simular delay de carregamento
    setTimeout(() => {
      setImages(portfolioImages);
      setLoading(false);
    }, 500);
  }, []);

  return (
    <section className="p-8 bg-pink-100 min-h-screen">
      <h2 className="text-3xl font-bold text-center text-pink-600 mb-4">Portfólio</h2>
      <p className="text-center text-gray-600 mb-8">
        Confira alguns dos nossos trabalhos mais recentes
      </p>

      {loading ? (
        <div className="grid md:grid-cols-3 gap-6">
          {[1, 2, 3].map((n) => (
            <div key={n} className="animate-pulse">
              <div className="w-full h-64 bg-gray-200 rounded-lg"></div>
            </div>
          ))}
        </div>
      ) : (
        <div className="grid md:grid-cols-3 gap-6">
          {images.map((image) => (
            <div key={image.id} className="relative group overflow-hidden rounded-lg shadow-lg">
              <img
                src={image.src}
                alt={image.alt}
                className="w-full h-64 object-cover transition-transform duration-300 group-hover:scale-105"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col items-center justify-center text-white p-4">
                <h3 className="text-xl font-semibold mb-2">{image.alt}</h3>
                <p className="text-sm">{image.category}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}

export default Portfolio;
