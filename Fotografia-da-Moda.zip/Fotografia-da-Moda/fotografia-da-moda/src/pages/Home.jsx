import AnimatedElement from '../components/AnimatedElement';
import OptimizedImage from '../components/OptimizedImage';
import Button from '../components/Button';

function Home() {
  const destaques = [
    {
      id: 1,
      title: 'Editorial de Moda',
      description: 'Criações únicas e conceituais',
      image: '/src/assets/images/editorial.jpg'
    },
    {
      id: 2,
      title: 'Campanhas',
      description: 'Fotografia comercial de alta qualidade',
      image: '/src/assets/images/campanhas.jpg'
    },
    {
      id: 3,
      title: 'Lookbook',
      description: 'Catálogos e coleções',
      image: '/src/assets/images/lookbook.jpg'
    }
  ];

  return (
    <div className="bg-pink-100 min-h-screen">
      <section className="text-center py-20">
        <AnimatedElement>
          <h1 className="text-5xl font-bold mb-6 text-pink-600">
            Bem-vinda ao universo da Fotografia de Moda
          </h1>
        </AnimatedElement>
        
        <AnimatedElement delay={0.2}>
          <p className="text-xl max-w-2xl mx-auto text-gray-700 mb-8">
            Capturamos tendências, elegância e estilo com olhar artístico e moderno.
          </p>
        </AnimatedElement>

        <AnimatedElement delay={0.4}>
          <Button 
            variant="primary"
            className="text-lg px-8 py-3"
            onClick={() => window.location.href = '/portfolio'}
          >
            Conheça nosso trabalho
          </Button>
        </AnimatedElement>
      </section>

  <section className="py-16 px-4">
        <AnimatedElement>
          <h2 className="text-3xl font-bold text-center mb-12">
            Nossos Serviços
          </h2>
        </AnimatedElement>

        <div className="max-w-6xl mx-auto grid md:grid-cols-3 gap-8">
          {destaques.map((destaque, index) => (
            <AnimatedElement key={destaque.id} delay={index * 0.2}>
              <div className="bg-white rounded-lg shadow-lg overflow-hidden transform hover:scale-105 transition-transform duration-300">
                <OptimizedImage
                  src={destaque.image}
                  alt={destaque.title}
                  className="w-full h-64 object-cover"
                />
                <div className="p-6">
                  <h3 className="text-xl font-semibold mb-2">{destaque.title}</h3>
                  <p className="text-gray-600">{destaque.description}</p>
                </div>
              </div>
            </AnimatedElement>
          ))}
        </div>
      </section>

  <section className="py-16 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <AnimatedElement>
            <h2 className="text-3xl font-bold mb-6">
              Transforme suas ideias em imagens memoráveis
            </h2>
            <p className="text-lg text-gray-700 mb-8">
              Entre em contato para criar seu próximo projeto fotográfico
            </p>
            <Button 
              variant="custom"
              className="text-lg px-8 py-3"
              onClick={() => window.location.href = '/contato'}
            >
              Agende uma sessão
            </Button>
          </AnimatedElement>
        </div>
      </section>
    </div>
  );
}
// ...existing code...

export default Home;
