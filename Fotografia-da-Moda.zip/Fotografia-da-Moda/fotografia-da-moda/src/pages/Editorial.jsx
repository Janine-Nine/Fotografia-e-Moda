function Editorial() {
  return (
    <section className="p-8 text-center bg-pink-100 min-h-screen">
      <h2 className="text-3xl font-bold text-pink-600 mb-4">Editorial de Moda</h2>
      <p className="text-gray-700 mb-6">
        Editorial inspirado nas tendências do ano, unindo arte, expressão e fotografia de alta costura.
      </p>
      <div className="flex flex-wrap justify-center gap-6">
        <div className="w-72 h-48 bg-gray-200 rounded-xl shadow-lg flex items-center justify-center">
          <span className="text-gray-500">Coloque imagens em /src/assets</span>
        </div>
        <div className="w-72 h-48 bg-gray-200 rounded-xl shadow-lg flex items-center justify-center">
          <span className="text-gray-500">Coloque imagens em /src/assets</span>
        </div>
        <div className="w-72 h-48 bg-gray-200 rounded-xl shadow-lg flex items-center justify-center">
          <span className="text-gray-500">Coloque imagens em /src/assets</span>
        </div>
      </div>
    </section>
  );
}
// ...existing code...
