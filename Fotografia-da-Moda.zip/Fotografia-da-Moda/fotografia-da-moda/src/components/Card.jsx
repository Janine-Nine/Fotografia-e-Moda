import PropTypes from 'prop-types';

function Card({ title, children, className = '' }) {
  return (
    <div className={`bg-pink-50 rounded-lg shadow-md hover:shadow-xl transition-shadow duration-300 p-6 ${className}`}>
      {title && (
        <h3 className="text-xl font-semibold mb-2 text-pink-600">{title}</h3>
      )}
      {children}
    </div>
  );
}

Card.propTypes = {
  title: PropTypes.string,
  children: PropTypes.node.isRequired,
  className: PropTypes.string
};

export default Card;