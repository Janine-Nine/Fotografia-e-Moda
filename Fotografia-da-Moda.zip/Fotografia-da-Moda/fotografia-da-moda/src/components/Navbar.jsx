import { Link } from "react-router-dom";

function Navbar() {
  return (
    <nav className="bg-black text-white p-4 flex flex-wrap justify-between items-center shadow-md">
      <h1 className="text-2xl font-bold tracking-wide text-pink-400">
        Fotografia da Moda
      </h1>
      <div className="flex gap-5 flex-wrap">
        <Link to="/" className="hover:text-pink-400">Início</Link>
        <Link to="/sobre" className="hover:text-pink-400">Sobre</Link>
        <Link to="/servicos" className="hover:text-pink-400">Serviços</Link>
        <Link to="/portfolio" className="hover:text-pink-400">Portfólio</Link>
        <Link to="/editorial" className="hover:text-pink-400">Editorial</Link>
        <Link to="/contato" className="hover:text-pink-400">Contato</Link>
      </div>
    </nav>
  );
}

export default Navbar;
