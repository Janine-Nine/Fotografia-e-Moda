import PropTypes from 'prop-types';

function Button({ children, variant = 'primary', className = '', ...props }) {
  const baseClasses = 'font-semibold rounded-md transition-colors duration-200';
  const variants = {
    primary: 'bg-pink-500 hover:bg-pink-600 text-white py-2 px-4',
    custom: 'border-2 border-purple-900 bg-white text-pink-500 hover:bg-pink-500 hover:text-white py-2 px-4'
  };

  return (
    <button
      className={`${baseClasses} ${variants[variant]} ${className}`}
      {...props}
    >
      {children}
    </button>
  );
}

Button.propTypes = {
  children: PropTypes.node.isRequired,
  variant: PropTypes.oneOf(['primary', 'custom']),
  className: PropTypes.string
};

export default Button;